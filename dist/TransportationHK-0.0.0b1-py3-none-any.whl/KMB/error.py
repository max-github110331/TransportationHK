# missing data
class MissingData(Exception):
    pass