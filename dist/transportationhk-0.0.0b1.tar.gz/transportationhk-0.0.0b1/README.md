# TransportationHK
TransportationHK is a python package(pypi) for Hong Kong Transport System, such as KMB, CityBus and MTR .
However, we are still developing this project so I only support KMB(LWB) data(Route, Stop and ETA).
Give us a star to support this project! Thank you very much.

## How to install?
Open your shell and enter `pip install TransportationHK`

## KMB (LWB)
[Click Me](https://github.com/max-github110331/TransportationHK/KMB/README.md)